#!/bin/bash
arr=(43 "sur" 32)
n=3
for (( i=0; i<n; i++ ))
	do
echo ${arr[$i]}
done
