#!/bin/bash
echo -e "HELLO\cmbORLD"
echo "HELLO\nWORLD "
echo -n e "HI\n hii"
echo "HELLO"
