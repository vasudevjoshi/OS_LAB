#!/bin/bash
car=("swift" "BMW" "BENZ")
echo "${car[@]}"
