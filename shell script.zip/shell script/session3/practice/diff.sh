#!/bin/bash
echo "a"
echo 'a'
b=10
echo "the value of b is:$b"
echo 'the value of b is:$b'
